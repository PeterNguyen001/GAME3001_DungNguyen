#include <glm/vec4.hpp>
#include <glm/gtx/type_trait.hpp>

int main()
{
	int Error = 0;

	

	return Error;
}

